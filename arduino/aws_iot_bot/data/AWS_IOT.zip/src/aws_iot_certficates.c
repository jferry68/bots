/*
 * Copyright 2010-2015 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * Additions Copyright 2016 Espressif Systems (Shanghai) PTE LTD
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 *  http://aws.amazon.com/apache2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */

/**
 * @file aws_iot_certifcates.c
 * @brief File to store the AWS certificates in the form of arrays
 */

#ifdef __cplusplus
extern "C" {
#endif

const char aws_root_ca_pem[] = {"-----BEGIN CERTIFICATE-----\n\
MIIDQTCCAimgAwIBAgITBmyfz5m/jAo54vB4ikPmljZbyjANBgkqhkiG9w0BAQsF\n\
ADA5MQswCQYDVQQGEwJVUzEPMA0GA1UEChMGQW1hem9uMRkwFwYDVQQDExBBbWF6\n\
b24gUm9vdCBDQSAxMB4XDTE1MDUyNjAwMDAwMFoXDTM4MDExNzAwMDAwMFowOTEL\n\
MAkGA1UEBhMCVVMxDzANBgNVBAoTBkFtYXpvbjEZMBcGA1UEAxMQQW1hem9uIFJv\n\
b3QgQ0EgMTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALJ4gHHKeNXj\n\
ca9HgFB0fW7Y14h29Jlo91ghYPl0hAEvrAIthtOgQ3pOsqTQNroBvo3bSMgHFzZM\n\
9O6II8c+6zf1tRn4SWiw3te5djgdYZ6k/oI2peVKVuRF4fn9tBb6dNqcmzU5L/qw\n\
IFAGbHrQgLKm+a/sRxmPUDgH3KKHOVj4utWp+UhnMJbulHheb4mjUcAwhmahRWa6\n\
VOujw5H5SNz/0egwLX0tdHA114gk957EWW67c4cX8jJGKLhD+rcdqsq08p8kDi1L\n\
93FcXmn/6pUCyziKrlA4b9v7LWIbxcceVOF34GfID5yHI9Y/QCB/IIDEgEw+OyQm\n\
jgSubJrIqg0CAwEAAaNCMEAwDwYDVR0TAQH/BAUwAwEB/zAOBgNVHQ8BAf8EBAMC\n\
AYYwHQYDVR0OBBYEFIQYzIU07LwMlJQuCFmcx7IQTgoIMA0GCSqGSIb3DQEBCwUA\n\
A4IBAQCY8jdaQZChGsV2USggNiMOruYou6r4lK5IpDB/G/wkjUu0yKGX9rbxenDI\n\
U5PMCCjjmCXPI6T53iHTfIUJrU6adTrCC2qJeHZERxhlbI1Bjjt/msv0tadQ1wUs\n\
N+gDS63pYaACbvXy8MWy7Vu33PqUXHeeE6V/Uq2V8viTO96LXFvKWlJbYK8U90vv\n\
o/ufQJVtMVT8QtPHRh8jrdkPSHCa2XV4cdFyQzR1bldZwgJcJmApzyMZFo6IQ6XU\n\
5MsI+yMRQ+hDKXJioaldXgjUkK642M4UwtBV8ob2xJNDd2ZhwLnoQdeXeGADbkpy\n\
rqXRfboQnoZsG4q5WTP468SQvvG5\n\
-----END CERTIFICATE-----\n"};

const char certificate_pem_crt[] = {"-----BEGIN CERTIFICATE-----\n\
MIIDWjCCAkKgAwIBAgIVAKe4qi4XC807h2OXoRpQJSv9YeQ3MA0GCSqGSIb3DQEB\n\
CwUAME0xSzBJBgNVBAsMQkFtYXpvbiBXZWIgU2VydmljZXMgTz1BbWF6b24uY29t\n\
IEluYy4gTD1TZWF0dGxlIFNUPVdhc2hpbmd0b24gQz1VUzAeFw0xODEyMjIyMDI4\n\
MTFaFw00OTEyMzEyMzU5NTlaMB4xHDAaBgNVBAMME0FXUyBJb1QgQ2VydGlmaWNh\n\
dGUwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDHuWu5+ryShHYAnzdM\n\
FEmO+Wbjf9o4KQeVXOwcpBnH7N5cze6sMVVKG58osqXg0fCzyuc/vY2NAihJyyRL\n\
YlAPtD47TYmPUpzNGVt7WJGqbYdqk9hUBKg4heCafW4Z6dvX5BSqLW1VDUlT6nWx\n\
0q5uvvmOkuwn13bPQhE5xtHiZH9nD7uzk8mOrB8TbBBBj6KzbwQWqu/grCTpZ8Ce\n\
rpMM7HDErv8LDW/VU6sJX4n7y7M+I7fKmN69BQ/IbqzlXks9jvzVKmxYuzgpQMyL\n\
2klyNm/Yi2LulFUkhxpO5ihiJ9j9sdveebKeheQ1t0d5+K32SqaZFzsslPNvzwfa\n\
xC47AgMBAAGjYDBeMB8GA1UdIwQYMBaAFGWILoBY8qFMiyi78ItA5dR//JyJMB0G\n\
A1UdDgQWBBSzC3/7l0N2OJGiYOokUwFUYbYMAzAMBgNVHRMBAf8EAjAAMA4GA1Ud\n\
DwEB/wQEAwIHgDANBgkqhkiG9w0BAQsFAAOCAQEAXrjAsVjNiH1F33m6tzI1hr8n\n\
osMkMyHG5svQ2q3xwd3aEcPUcHeein+NKgQdB3ivk5Zp9MPtAlamA0Rv6Suuf1Qn\n\
GoAe0d/zzFK2vgOQ3I5QPXCmdDm0ldDH+JpIzNQoVxPEI9x0ZPbMJJ3VixZ8o/Vp\n\
A4MUdnuoKXuBuy89twlqYrzjxakEEJlJesQP1UJDDlB3j1uRYFyqUd52tzdZcNKu\n\
/Ay4mZfJWyAQdTODl9MfnTGPrMJm1z4T6opN/3THe4D38KMt35L02pdB5z9L1F8w\n\
5Fbmh3S6KswIcKH/9IhE1g2lZQbPVx/wOQLBu2njlgKwJGKvp6OyMDiDc1LciA==\n\
-----END CERTIFICATE-----\n"};

const char private_pem_key[] = {"-----BEGIN RSA PRIVATE KEY-----\n\
MIIEogIBAAKCAQEAx7lrufq8koR2AJ83TBRJjvlm43/aOCkHlVzsHKQZx+zeXM3u\n\
rDFVShufKLKl4NHws8rnP72NjQIoScskS2JQD7Q+O02Jj1KczRlbe1iRqm2HapPY\n\
VASoOIXgmn1uGenb1+QUqi1tVQ1JU+p1sdKubr75jpLsJ9d2z0IROcbR4mR/Zw+7\n\
s5PJjqwfE2wQQY+is28EFqrv4Kwk6WfAnq6TDOxwxK7/Cw1v1VOrCV+J+8uzPiO3\n\
ypjevQUPyG6s5V5LPY781SpsWLs4KUDMi9pJcjZv2Iti7pRVJIcaTuYoYifY/bHb\n\
3nmynoXkNbdHefit9kqmmRc7LJTzb88H2sQuOwIDAQABAoIBAB0ecJFd+C5Yd6fh\n\
jrtd3deljxWuJ0+20684LAiE+GlIpKbdM2YRj0DNxCe33C1qDnD4LT0C0udzIBKa\n\
NoFzJP8VJVmaFWs6/Td98fOK1zoE3BBy28BsKWaMRlHf5bSLfwz76PNiyiTzWfSN\n\
I3m4oMvutg3OZ/XrGRxgoohM737VLDA0pD6ttcy7oqmdrGAOM/k/TQMZNIzkpfRn\n\
Wf2MaJ13JflOQw6TiLAUNRGLMthn/2rVJW+Iz0fVq3+vmM1REsrWJElVdhMYc2IR\n\
IcMm+Q0SNE5A1bhppQZ345xUdSEONkrQQ6/yaTjvtKrjIGpGkbGuRuy8BJrhEH+p\n\
HxFDe7kCgYEA6jf3wYqeUiWCiUUIpt88Lxeio3RLMFXZ3OThl7T9X7FWyKP1ZHwQ\n\
YDsQvVFDmFCJ27Kv6IjCEtSkzuIAyKJwCpiga6O5Jy68heXHtfdVNWHL/lG20JPA\n\
7sQOM0qHNnC6AEa5uzTemJOzHHdBSKLH3axaD2dD1CmNoMipCFHV23cCgYEA2kw/\n\
iYsnVz+K23WW/Ksa5HIMdSV9Tzn73fIcDUrv+HHorJcIhiWt2yB+UrSzCrr2L3Rl\n\
XIO28grpm8UY3eMf+dyN7Jh3J010KuUtYLvHD+/bOpBB6V6RIYSJdTl4p0Ji2jbj\n\
KaHcOqp690Hvn8w0znXTiBVfuytHiKWNE0U9LF0CgYBhQFPzXOdYHJMTBEMPZunK\n\
c/nn/MWrkDoh6jdxkokSTsRGEy41Rv5VtrDAqxlyCR70xkEcQIy03O6BqH3C0Q/M\n\
loslppmel11YC4zdFZGf1LerJarO+ErH2Ug8K9nw1OWmb7d28ADtQYbBbxMAYfaz\n\
KHlMpAgZ9BcGh8sH1VMDCQKBgEX5yyQ8BxBgvhI7T3sPHj+8j2G98r1CyQoMYhGg\n\
w+vQF9W7VHAsA98KO3QnmH0IEYKEvTk6v5o3BUt5ks8Nz2I44QXGmetvWJ2neTRY\n\
/SaOrKfJNleoiL1FzwpUsehrz2RD0+20hPQJUgGQkU+YFhVYj8Y/k8Bbz0JuTxqu\n\
Rz3BAoGAFxS3qUNzbVlN5TV2OgtN0IIgcUqvnR+tZTQNnzSCZBG9zWshtcU4sf1b\n\
aUEIPe0WYo/o70QfgSjPdTtEv83VYIF9TPOutlg/K+di3D8IMHTtYKouHvIx+asl\n\
ucXkVSi70LZAjPCb0hiF+StwKhys8i/1GLA91yg+TQsrSEux6cI=\n\
-----END RSA PRIVATE KEY-----\n"};


#ifdef __cplusplus
}
#endif
